import Team1 from "../assets/img/team1.png";
import Team2 from "../assets/img/team2.png";
export const TeamData = [
  {
    img: Team1,
    title: "Chuck G",
    desc: "Member of the team",
  },
  {
    img: Team2,
    title: "Jon",
    desc: "Member of the team",
  },
  {
    img: Team1,
    title: "Chuck G",
    desc: "Member of the team",
  },
  {
    img: Team2,
    title: "Jon",
    desc: "Member of the team",
  },
  {
    img: Team1,
    title: "Chuck G",
    desc: "Member of the team",
  },
  {
    img: Team2,
    title: "Jon",
    desc: "Member of the team",
  },
  {
    img: Team1,
    title: "Chuck G",
    desc: "Member of the team",
  },
  {
    img: Team2,
    title: "Jon",
    desc: "Member of the team",
  },
  {
    img: Team1,
    title: "Chuck G",
    desc: "Member of the team",
  },
];
