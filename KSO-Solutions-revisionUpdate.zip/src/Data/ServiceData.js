export const ServiceData = [
  {
    icon: "fas fa-globe",
    title: "Service 1",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fas fa-server",
    title: "Service 2",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fab fa-react",
    title: "Service 3",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "far fa-file-code",
    title: "Service 4",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fas fa-fish",
    title: "Service 5",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fas fa-user-secret",
    title: "Service 6",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fas fa-laptop-code",
    title: "Service 7",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fas fa-bug",
    title: "Service 8",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
  {
    icon: "fas fa-network-wired",
    title: "Service 9",
    para: "Lorem Ipsum sit amendment maneuver anatomy sit ditrum amet hasli anter",
  },
];